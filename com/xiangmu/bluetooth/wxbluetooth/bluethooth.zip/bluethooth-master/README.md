# bluethooth
微信小程序 连接热敏打印机打印 解决了中文乱码问题
[微信小程序小票打印功能（以及中文乱码的解决）](https://www.jianshu.com/p/20419462e381)
